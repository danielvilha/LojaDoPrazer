/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lojadoprazer;

/**
 *
 * @author danielvilha
 */
public class Logout {
    
    public static void Logout() {
        System.out.println("----------------- Obrigado por usar o sistema. -----------------");
        System.exit(0);
    }
}
